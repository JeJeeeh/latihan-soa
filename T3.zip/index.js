const express = require('express');
const app = express();
const port = 3000;
const siteRouter = require('./src/routes/site');
const database = require('./src/databases/connection');

app.use(express.urlencoded({ extended: true }));
app.use("/api", siteRouter);

const initApp = async () => {
  console.log("Testing database connection...");
  try {
    await database.authenticate();
    console.log("Database connection successful!");

    app.listen(port, () =>
      console.log(`Example app listening on port ${port}!`)
    );
  } catch (error) {
    console.error(error.original);
  }
};

initApp();