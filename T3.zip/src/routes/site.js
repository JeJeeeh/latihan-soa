const express = require("express");
const Controller = require("../controllers/site");
const router = express.Router();

router.post("/user", (req, res) => {
	const result = Controller.register(
		req.body.username,
		req.body.password,
		req.body.nama,
		req.body.alamat,
		req.body.nomorhp
	);
	if (result) {
		res.status(201).json({
			message: "User registered successfully!",
		});
	} else {
		res.status(500).send("Error registering user!");
	}
});

router.post("/login", Controller.login);
router.put("/user/:username", Controller.update);

router.post("/friend", Controller.addFriend);
router.get("/friend/:username", Controller.getFriends);
router.delete("/friend/", Controller.deleteFriend);

router.post("/message", Controller.sendMessage);
router.get("/message/:username", Controller.getMessages);

module.exports = router;
