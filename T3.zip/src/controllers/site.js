const { QueryTypes } = require("sequelize");
const connection = require("../databases/connection");

const login = async (req, res) => {
	const result = await connection.query(
		"SELECT * FROM user WHERE username = ? AND password = ?",
		{
			type: QueryTypes.SELECT,
			replacements: [req.body.username, req.body.password],
		}
	);

	if (result.length > 0) {
		res.status(200).json({
			message: "User logged in successfully!",
			data: result,
		});
	} else {
		res.status(500).send("Error logging in user!");
	}
};

const update = async (req, res) => {
	const result = await connection.query(
		"UPDATE user SET password = ?, name = ?, address = ?, phone = ? WHERE username = ?",
		{
			type: QueryTypes.UPDATE,
			replacements: [
				req.body.newpassword,
				req.body.nama,
				req.body.alamat,
				req.body.nomorhp,
				req.params.username,
			],
		}
	);

	if (result) {
		res.status(200).json({
			message: "User updated successfully!",
		});
	} else {
		res.status(500).send("Error updating user!");
	}
};

const addFriend = async (req, res) => {
	const result = await connection.query(
		"SELECT * FROM user WHERE username = ? AND password = ?",
		{
			type: QueryTypes.SELECT,
			replacements: [req.body.username, req.body.password],
		}
	);

	if (result.length > 0) {
		const result2 = await connection.query(
			"SELECT * FROM user WHERE username = ?",
			{
				type: QueryTypes.SELECT,
				replacements: [req.body.usercari],
			}
		);

		if (result2.length > 0) {
			await connection.query(
				"INSERT INTO friend (host, friend, username, nama, alamat, nomorhp) VALUES (?, ?, ?, ?, ?, ?)",
				{
					type: QueryTypes.INSERT,
					replacements: [
						result[0]["id"],
						result2[0]["id"],
						result2[0]["username"],
						result2[0]["name"],
						result2[0]["address"],
						result2[0]["phone"],
					],
				}
			);
			res.status(200).json({
				message: "Friend berhasil ditambahkan!",
			});
		} else {
			res.status(500).json({
				message: "User tidak ditemukan!",
			});
		}
	} else {
		res.status(500).send("User tidak ditemukan atau salah password");
	}
};

const getFriends = async (req, res) => {
	const result = await connection.query(
		"SELECT * FROM user WHERE username = ? AND password = ?",
		{
			type: QueryTypes.SELECT,
			replacements: [req.params.username, req.body.password],
		}
	);

	if (result.length > 0) {
		const result2 = await connection.query(
			"SELECT * FROM friend WHERE host = ?",
			{
				type: QueryTypes.SELECT,
				replacements: [result[0]["id"]],
			}
		);

		if (result2.length > 0) {
			const friends = [];
			result2.forEach((friend) => {
				friends.push({
					[friend["username"]]: {
						nama: friend["nama"],
						alamat: friend["alamat"],
						nomorhp: friend["nomorhp"],
					},
				});
			});
			res.status(200).json({
				message: "Berhasil mendapatkan daftar teman!",
				data: friends,
			});
		} else {
			res.status(500).json({
				message: "User tidak ditemukan!",
			});
		}
	} else {
		res.status(500).send("User tidak ditemukan atau salah password");
	}
};

const deleteFriend = async (req, res) => {
	const result = await connection.query(
		"SELECT * FROM user WHERE username = ? AND password = ?",
		{
			type: QueryTypes.SELECT,
			replacements: [req.body.username, req.body.password],
		}
	);

	if (result.length > 0) {
		const result2 = await connection.query(
			"SELECT * FROM user WHERE username = ?",
			{
				type: QueryTypes.SELECT,
				replacements: [req.body.usercari],
			}
		);

		if (result2.length > 0) {
			await connection.query(
				"DELETE FROM friend WHERE host = ? AND friend = ?",
				{
					type: QueryTypes.DELETE,
					replacements: [result[0]["id"], result2[0]["id"]],
				}
			);
			res.status(200).json({
				message: "Friend berhasil dihapus!",
			});
		} else {
			res.status(500).json({
				message: "User tidak ditemukan!",
			});
		}
	} else {
		res.status(500).send("User tidak ditemukan atau salah password");
	}
};

const sendMessage = async (req, res) => {
	const result = await connection.query(
		"SELECT * FROM user WHERE username = ? AND password = ?",
		{
			type: QueryTypes.SELECT,
			replacements: [req.body.username, req.body.password],
		}
	);

	if (result.length > 0) {
		const result2 = await connection.query(
			"SELECT * FROM user WHERE username = ?",
			{
				type: QueryTypes.SELECT,
				replacements: [req.body.usercari],
			}
		);

		if (result2.length > 0) {
			await connection.query(
				"INSERT INTO message (sender, receiver, from_username, to_username, message) VALUES (?, ?, ?, ?, ?)",
				{
					type: QueryTypes.INSERT,
					replacements: [
						result[0]["id"],
						result2[0]["id"],
						result[0]["username"],
						result2[0]["username"],
						req.body.message,
					],
				}
			);
			res.status(200).json({
				message: "Message berhasil dikirim!",
			});
		} else {
			res.status(500).json({
				message: "User tidak ditemukan!",
			});
		}
	} else {
		res.status(500).send("User tidak ditemukan atau salah password");
	}
};

const getMessages = async (req, res) => {
	const result = await connection.query(
		"SELECT * FROM user WHERE username = ? AND password = ?",
		{
			type: QueryTypes.SELECT,
			replacements: [req.params.username, req.body.password],
		}
	);

	if (result.length > 0) {
		const result2 = await connection.query(
			"SELECT * FROM message WHERE sender = ?",
			{
				type: QueryTypes.SELECT,
				replacements: [result[0]["id"]],
			}
		);

		if (result2.length > 0) {
			const messages = [];
			result2.forEach((message) => {
				messages.push({
					from: message["from_username"],
					to: message["to_username"],
					message: message["message"],
				});
			});
			res.status(200).json({
				message: "Berhasil mendapatkan daftar pesan!",
				data: messages,
			});
		} else {
			res.status(500).json({
				message: "User belum mengirim pesan!",
			});
		}
	} else {
		res.status(500).send("User tidak ditemukan atau salah password");
	}
};

module.exports = {
	register: async (username, password, customer_name, address, phone) => {
		const result = await connection.query(
			"INSERT INTO user (username, password, name, address, phone) VALUES (?, ?, ?, ?, ?)",
			{
				type: QueryTypes.INSERT,
				replacements: [username, password, customer_name, address, phone],
			}
		);

		return await result;
	},
	login,
	update,
	addFriend,
	getFriends,
	deleteFriend,
	sendMessage,
	getMessages,
};
